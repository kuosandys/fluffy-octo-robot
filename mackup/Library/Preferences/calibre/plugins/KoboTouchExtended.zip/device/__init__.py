"""KoboTouchExtended device driver."""
